A Pen created at CodePen.io. You can find this one at https://codepen.io/MarcMalignan/pen/jABfk.

 Using Google Maps API as a service in an Angular app.