const express = require ('express');
const ajax = require ('ajax');
//const path = require ('path');

const app= express();

app.use('/css',express.static('css'));
app.use('/js',express.static('js'));

app.get('/*/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});

app.listen(5000,function(req,res) {
     console.log('port is runnig on localhost:5000')
})